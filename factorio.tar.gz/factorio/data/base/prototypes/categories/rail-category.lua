data:extend(
{
  {
    type = "rail-category",
    name = "regular"
  }
}
)
