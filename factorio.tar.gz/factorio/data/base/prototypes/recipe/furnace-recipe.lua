data:extend(
{
  {
    type = "recipe",
    name = "steel-plate",
    category = "smelting",
    enabled = false,
    energy_required = 17.5,
    ingredients = {{"iron-plate", 5}},
    result = "steel-plate"
  }
}
)
