data:extend(
{
  {
    type = "noise-layer",
    name = "grass"
  },
  {
    type = "noise-layer",
    name = "grass-medium"
  },
  {
    type = "noise-layer",
    name = "grass-dry"
  },
  {
    type = "noise-layer",
    name = "dirt"
  },
  {
    type = "noise-layer",
    name = "dirt-dark"
  },
  {
    type = "noise-layer",
    name = "sand"
  },
  {
    type = "noise-layer",
    name = "sand-dark"
  },
  {
    type = "noise-layer",
    name = "copper-ore"
  },
  {
    type = "noise-layer",
    name = "iron-ore"
  },
  {
    type = "noise-layer",
    name = "coal"
  },
  {
    type = "noise-layer",
    name = "stone"
  },
  {
    type = "noise-layer",
    name = "crude-oil"
  },
  {
    type = "noise-layer",
    name = "enemy-base"
  },
}
)
