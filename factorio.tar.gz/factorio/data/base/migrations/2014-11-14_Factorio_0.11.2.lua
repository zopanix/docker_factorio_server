game.reload_script()
